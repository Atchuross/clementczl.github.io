//
//  Epee.swift
//  MY_RPG
//
//  Created by clément czl on 11/01/2020.
//  Copyright © 2020 ATCEntertainement. All rights reserved.
//

class Epee: Arme {
    init() {
        super.init(degats: 10)
    }
}
